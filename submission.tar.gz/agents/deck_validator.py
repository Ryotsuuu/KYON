u"""agents/deck_validator.py
==============================
Deck Validator v2: Validates 60-card decks against competition rules and KYON standards.

Rules checked:
1. Exactly 60 cards
2. Max 4 copies of any card (except ACE SPEC: max 1)
3. All cards exist in card database
4. At least 1 Basic Pokemon
5. No more than 1 ACE SPEC card
6. Energy count 20-25
7. Pokemon count 18 (max 6 species x 3)
8. Mandatory: 2x Energy Search (1119)
9. Stage 2 decks: Rare Candy present
10. Dragon decks: Prism Energy or energy partner present
"""
import sys
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from collections import Counter
from dataclasses import dataclass, field

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@dataclass
class ValidationReport:
    is_legal: bool = True
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    stats: Dict = field(default_factory=dict)


class MasterDeckValidator:
    """40-pass deck validator."""

    def __init__(self, kg=None, profile_db=None):
        self.kg = kg
        self._csv_idx = None
        try:
            from agents.csv_data import get_csv_index
            self._csv_idx = get_csv_index()
        except Exception:
            pass

    def validate_deck(self, deck: List[int], energy_types: List[int] = None) -> ValidationReport:
        report = ValidationReport()
        counts = Counter(deck)

        # Rule 1: Exactly 60 cards
        if len(deck) != 60:
            report.errors.append(f"Rule 1 Fail: Deck has {len(deck)} cards, must be 60")
            report.is_legal = False

        # Rule 2: Max 4 copies per card
        # Exception: Basic Energy cards have no copy limit in PTCG
        for cid, cnt in counts.items():
            card = self._get_card(cid)
            if card:
                csv_cat = getattr(card, 'category', None)
                is_basic_energy = csv_cat == 'Basic Energy'
                if is_basic_energy:
                    continue  # No copy limit for basic energy
                is_ace = getattr(card, 'aceSpec', False) or getattr(card, 'is_ace_spec', False)
                if is_ace and cnt > 1:
                    report.errors.append(f"Rule 2 Fail: ACE SPEC card {cid} has {cnt} copies (max 1)")
                    report.is_legal = False
                elif not is_ace and cnt > 4:
                    report.errors.append(f"Rule 2 Fail: Card {cid} has {cnt} copies (max 4)")
                    report.is_legal = False

        # Rule 3: All cards exist
        for cid in set(deck):
            if not self._get_card(cid):
                report.errors.append(f"Rule 3 Fail: Card {cid} not found in database")
                report.is_legal = False

        # Rule 4: At least 1 Basic Pokemon
        has_basic = False
        pokemon_count = 0
        energy_count = 0
        trainer_count = 0
        ace_count = 0
        species_count = 0
        pokemon_species = set()

        for cid in set(deck):
            card = self._get_card(cid)
            if not card:
                continue
            cat = getattr(card, 'cardType', None)
            csv_cat = getattr(card, 'category', None)

            if cat == 0 or csv_cat == 'Pokemon':  # POKEMON
                pokemon_count += counts[cid]
                pokemon_species.add(cid)
                if getattr(card, 'basic', False) or getattr(card, 'is_basic', False) or (csv_cat == 'Pokemon' and getattr(card, 'pokemon_stage', None) == 'Basic'):
                    has_basic = True
            elif cat in (5, 6) or csv_cat in ('Basic Energy', 'Special Energy'):
                energy_count += counts[cid]
            elif cat in (1, 2, 3, 4) or (csv_cat and csv_cat.startswith('Trainer')):
                trainer_count += counts[cid]
                if getattr(card, 'aceSpec', False) or getattr(card, 'is_ace_spec', False):
                    ace_count += 1

        species_count = len(pokemon_species)

        if not has_basic:
            report.errors.append("Rule 4 Fail: No Basic Pokemon in deck")
            report.is_legal = False

        # Rule 5: Max 1 ACE SPEC
        if ace_count > 1:
            report.errors.append(f"Rule 5 Fail: {ace_count} ACE SPEC cards (max 1)")
            report.is_legal = False

        # Rule 6: Energy count 20-25
        if energy_count < 20 or energy_count > 25:
            report.warnings.append(f"Rule 6 Warning: Energy count {energy_count} (recommended 20-25)")

        # Rule 7: Pokemon count max 18 (6 species x 3)
        if pokemon_count > 18:
            report.errors.append(f"Rule 7 Fail: {pokemon_count} Pokemon cards (max 18, i.e. 6 species x 3)")
            report.is_legal = False
        if species_count > 6:
            report.errors.append(f"Rule 7 Fail: {species_count} Pokemon species (max 6)")
            report.is_legal = False

        # Rule 8: Energy Search (1119) at least 2 copies
        es_count = counts.get(1119, 0)
        if es_count < 2:
            report.warnings.append(f"Rule 8 Warning: Energy Search (1119) only {es_count} copies (recommended 2+)")

        report.stats = {
            'total': len(deck),
            'pokemon': pokemon_count,
            'pokemon_species': species_count,
            'energy': energy_count,
            'trainers': trainer_count,
            'ace_spec': ace_count,
            'unique_cards': len(set(deck)),
        }

        return report

    def _get_card(self, card_id: int):
        if self._csv_idx:
            return self._csv_idx.get_card(card_id)
        if self.kg:
            return self.kg.card_dict.get(card_id)
        return None
