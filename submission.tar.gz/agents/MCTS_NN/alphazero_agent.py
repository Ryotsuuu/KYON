"""
agents/MCTS_NN/alphazero_agent.py
==================================
AlphaZero-style MCTS + Neural Network Agent with Hive-Mind Policy-Value Guidance.

Integrates:
- HiveMindPolicyValueNet for PUCT action priors and position evaluation
- MasterAgent v3 context handlers for all non-MAIN SelectContexts
- Self-play training pipeline for policy-value iteration
"""
import sys
import math
import random
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cg.api import (
    to_observation_class, OptionType, SelectContext, CardType,
    search_begin, search_step, search_end,
)
from agents.NN import get_hive_mind_net, encode_dynamic_state, ACTION_DIM
from simulation.Decision_Engine import MasterAgent
from agents.Learning_System import get_replay_buffer
from agents.Resource_Management.simulation_runner import battle_start, battle_select, battle_finish

logger = logging.getLogger(__name__)


class AlphaZeroNode:
    """Node in the AlphaZero MCTS search tree."""
    __slots__ = ("parent", "action", "children", "visits", "total_value", "prior")

    def __init__(self, parent=None, action=None, prior: float = 0.0):
        self.parent = parent
        self.action = action
        self.children: List[AlphaZeroNode] = []
        self.visits = 0
        self.total_value = 0.0
        self.prior = prior

    @property
    def q_value(self) -> float:
        return self.total_value / max(1, self.visits)

    def puct_score(self, cpuct: float = 1.5) -> float:
        parent_visits = self.parent.visits if self.parent else 1
        explore = cpuct * self.prior * math.sqrt(parent_visits) / (1 + self.visits)
        return self.q_value + explore

    def best_child(self, cpuct: float = 1.5):
        return max(self.children, key=lambda c: c.puct_score(cpuct))

    def expand(self, action_priors: List[Tuple[int, float]]):
        existing = {c.action for c in self.children}
        for action, prior in action_priors:
            if action not in existing:
                self.children.append(AlphaZeroNode(parent=self, action=action, prior=prior))

    def backpropagate(self, value: float):
        node = self
        while node is not None:
            node.visits += 1
            node.total_value += value
            node = node.parent


class AlphaZeroAgent:
    """AlphaZero MCTS Agent guided by Hive-Mind Neural Network."""

    def __init__(self, deck=None, simulations: int = 20, cpuct: float = 1.5, temperature: float = 1.0):
        self.deck = deck or [1] * 60
        self.name = "AlphaZeroAgent"
        self.version = "8.0-HiveMind"
        self.simulations = simulations
        self.cpuct = cpuct
        self.temperature = temperature
        self.stats = {"games": 0, "wins": 0, "losses": 0, "mcts_searches": 0, "nn_evals": 0}
        self.hive_mind = get_hive_mind_net()
        self.master_fallback = MasterAgent(deck=self.deck)

    def __call__(self, obs_dict: Any) -> List[int]:
        """Competition entry point: agent(obs_dict) -> list[int]."""
        try:
            obs = to_observation_class(obs_dict)
            if obs.select is None:
                return self.deck

            ctx = obs.select.context
            if ctx != SelectContext.MAIN:
                return self.master_fallback(obs_dict)

            options = obs.select.option
            if not options:
                return []
            if len(options) == 1:
                return [0]

            return self._search_main(obs, options)
        except Exception:
            return self.master_fallback(obs_dict)

    def _search_main(self, obs, options) -> List[int]:
        root = AlphaZeroNode()
        state_vec = encode_dynamic_state(obs)
        policy_probs, root_val = self.hive_mind.predict(state_vec)
        self.stats["nn_evals"] += 1

        num_options = min(len(options), ACTION_DIM)
        priors = policy_probs[:num_options]
        total_p = sum(priors)
        if total_p > 0:
            priors = [p / total_p for p in priors]
        else:
            priors = [1.0 / num_options] * num_options

        action_priors = list(enumerate(priors))
        root.expand(action_priors)

        for _ in range(self.simulations):
            node = root
            while node.children:
                node = node.best_child(self.cpuct)

            _, leaf_value = self.hive_mind.predict(state_vec)
            node.backpropagate(leaf_value)

        self.stats["mcts_searches"] += 1

        if root.children:
            best_child = max(root.children, key=lambda c: c.visits)
            best_idx = best_child.action
            if 0 <= best_idx < len(options):
                return [best_idx]

        return [0]


def self_play_training(deck1: List[int], deck2: List[int], num_games: int = 5, epochs: int = 2) -> Dict[str, Any]:
    """Execute self-play games between AlphaZero agents and train Hive-Mind Policy-Value Network."""
    agent1 = AlphaZeroAgent(deck=deck1, simulations=15)
    agent2 = AlphaZeroAgent(deck=deck2, simulations=15)
    buffer = get_replay_buffer()

    wins_p1 = 0
    wins_p2 = 0

    for g_idx in range(num_games):
        obs, sd = battle_start(deck1, deck2)
        if obs is None:
            battle_finish()
            continue

        states = []
        turns = 0

        try:
            while obs and obs.get('select') is not None and turns < 60:
                p_idx = obs.get('current', {}).get('yourIndex', 0)
                active_agent = agent1 if p_idx == 0 else agent2
                try:
                    act = active_agent(obs)
                    if not act:
                        act = []
                except Exception:
                    act = [0]
                states.append(obs.get('current', {}))
                try:
                    obs = battle_select(act)
                except Exception:
                    break
                turns += 1

            winner = 2
            if obs and 'current' in obs:
                winner = obs['current'].get('result', 2)
            if winner == 0:
                wins_p1 += 1
            elif winner == 1:
                wins_p2 += 1

            buffer.add_game(winner, deck1, deck2, turns, "AlphaZero_P1", "AlphaZero_P2", states=states)
        finally:
            battle_finish()

    buffer.save()
    train_res = get_hive_mind_net().train_on_replays(epochs=epochs)

    return {
        'games_played': num_games,
        'wins_p1': wins_p1,
        'wins_p2': wins_p2,
        'training_result': train_res,
    }
