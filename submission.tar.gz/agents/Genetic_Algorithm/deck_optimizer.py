"""
agents/Genetic_Algorithm/deck_optimizer.py
=========================================
Genetic Algorithm Deck Optimizer with Strict Legality Repair & Protection.

Guarantees:
- Exactly 60 cards
- Max 4 copies of any non-basic energy card
- Max 1 ACE SPEC card per deck
- At least 1 Basic Pokémon (enforces legal starting hand)
- Max 6 Pokémon species lines (max 18 Pokémon total)
- Category & Energy compatibility preservation
"""
import copy
import random
import logging
from collections import Counter
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Any

from agents.csv_data import CsvDataIndex, get_csv_index
from agents.Learning_System.replay_buffer import get_replay_buffer

logger = logging.getLogger(__name__)


class Individual:
    """A single deck candidate in the GA population."""

    def __init__(self, deck: List[int], agent_id: str = '', generation: int = 0):
        self.deck = list(deck)
        self.agent_id = agent_id
        self.generation = generation
        self.fitness = 0.0
        self.win_rate = 0.0
        self.wins = 0
        self.losses = 0
        self.draws = 0
        self.games_played = 0

    def copy(self) -> 'Individual':
        ind = Individual(self.deck, self.agent_id, self.generation)
        ind.fitness = self.fitness
        ind.win_rate = self.win_rate
        ind.wins = self.wins
        ind.losses = self.losses
        ind.draws = self.draws
        ind.games_played = self.games_played
        return ind


class GeneticOptimizer:
    """Genetic Algorithm for optimizing PTCG decks with strict chromosome repair."""

    def __init__(
        self,
        base_deck: List[int],
        population_size: int = 12,
        mutation_rate: float = 0.35,
        crossover_rate: float = 0.65,
        elite_count: int = 2,
        seed: int = 42,
        csv_index: Optional[CsvDataIndex] = None,
        energy_types: Optional[List[str]] = None,
        archetype: Optional[str] = None,
    ):
        self.base_deck = list(base_deck)
        self.population_size = max(4, population_size)
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.elite_count = elite_count
        self.rng = random.Random(seed)
        self._csv_idx = csv_index or get_csv_index(Path("data"))
        self.energy_types = list(energy_types) if energy_types else self._infer_energy_types(self.base_deck)
        self.archetype = archetype or "balanced"
        self.generation = 0
        self.best_ever: Optional[Individual] = None
        self.population: List[Individual] = []
        self._initialize_population()

    def _infer_energy_types(self, deck: List[int]) -> List[str]:
        """Infer the elemental energy types present in the base deck."""
        energy_map = {
            1: 'Grass', 2: 'Fire', 3: 'Water', 4: 'Lightning',
            5: 'Psychic', 6: 'Fighting', 7: 'Darkness', 8: 'Metal', 9: 'Dragon',
            18: 'Grass', 19: 'Psychic', 20: 'Fighting',
        }
        types = []
        for cid in deck:
            if cid in energy_map:
                t = energy_map[cid]
                if t not in types:
                    types.append(t)
        return types or ['Psychic']

    def _get_primary_energy_id(self) -> int:
        """Get basic energy ID for the deck's primary element."""
        mapping = {
            'Grass': 1, 'Fire': 2, 'Water': 3, 'Lightning': 4,
            'Psychic': 5, 'Fighting': 6, 'Darkness': 7, 'Metal': 8, 'Dragon': 9
        }
        primary = self.energy_types[0] if self.energy_types else 'Psychic'
        return mapping.get(primary, 5)

    def _initialize_population(self, opponent_deck: Optional[List[int]] = None):
        """Create diverse initial population mutated legally from base deck."""
        self.population = [Individual(deck=self.base_deck, agent_id="seed_base", generation=0)]
        for i in range(1, self.population_size):
            mutated = self._mutate(list(self.base_deck))
            self.population.append(Individual(deck=mutated, agent_id=f"init_{i}", generation=0))
        self.evaluate_population(opponent_deck)

    def evaluate_population(self, opponent_deck: Optional[List[int]] = None):
        """Evaluate fitness of population via high-throughput simulations."""
        from agents.Resource_Management.simulation_runner import get_simulation_runner
        runner = get_simulation_runner()
        opp = opponent_deck or self.base_deck

        for ind in self.population:
            if ind.games_played == 0:
                res = runner.run_simulations(ind.deck, opp, total_games=4)
                ind.wins = res['wins_p1']
                ind.losses = res['wins_p2']
                ind.draws = res['draws']
                ind.games_played = res['completed_games']
                ind.win_rate = ind.wins / ind.games_played if ind.games_played > 0 else 0.0
                ind.fitness = ind.win_rate * 100.0 + self.rng.uniform(0.1, 0.9)

    def evolve(self, opponent_deck: Optional[List[int]] = None) -> List[Individual]:
        """Advance population by one generation using tournament selection, crossover, mutation, and elite preservation."""
        self.evaluate_population(opponent_deck)
        self.population.sort(key=lambda x: x.fitness, reverse=True)
        if not self.best_ever or self.population[0].fitness > self.best_ever.fitness:
            self.best_ever = self.population[0].copy()

        next_gen = []

        # 1. Elitism: preserve top individuals
        for i in range(min(self.elite_count, len(self.population))):
            elite = self.population[i].copy()
            elite.generation = self.generation + 1
            next_gen.append(elite)

        # 2. Crossover & Mutation for offspring
        while len(next_gen) < self.population_size:
            if self.rng.random() < self.crossover_rate and len(self.population) >= 2:
                p1 = self._tournament_select()
                p2 = self._tournament_select()
                child_deck = self._crossover(p1.deck, p2.deck)
            else:
                p = self._tournament_select()
                child_deck = list(p.deck)

            if self.rng.random() < self.mutation_rate:
                child_deck = self._mutate(child_deck)

            # Strict Chromosome Legality Repair
            repaired_deck = self._repair_deck(child_deck)

            next_gen.append(Individual(
                deck=repaired_deck,
                agent_id=f"gen{self.generation+1}_{len(next_gen)}",
                generation=self.generation + 1,
            ))

        self.population = next_gen
        self.evaluate_population(opponent_deck)
        self.generation += 1
        return self.population

    def _tournament_select(self, k: int = 3) -> Individual:
        candidates = self.rng.sample(self.population, min(k, len(self.population)))
        return max(candidates, key=lambda x: x.fitness)

    def _crossover(self, deck1: List[int], deck2: List[int]) -> List[int]:
        """Uniform crossover between two parent chromosomes."""
        child = []
        pad_id = self._get_primary_energy_id()
        for i in range(60):
            d1_val = deck1[i] if i < len(deck1) else pad_id
            d2_val = deck2[i] if i < len(deck2) else pad_id
            child.append(d1_val if self.rng.random() < 0.5 else d2_val)
        return self._repair_deck(child)

    def _mutate(self, deck: List[int]) -> List[int]:
        """Mutate deck by swapping 1-3 non-mandatory cards with legal alternatives."""
        deck = list(deck)
        n_swaps = self.rng.randint(1, 3)
        counts = Counter(deck)

        for _ in range(n_swaps):
            swappable = [i for i, cid in enumerate(deck) if not self._is_protected(cid, counts)]
            if not swappable:
                break

            idx = self.rng.choice(swappable)
            old_cid = deck[idx]
            new_cid = self._find_replacement(old_cid, deck, counts)
            if new_cid and new_cid != old_cid:
                deck[idx] = new_cid
                counts[old_cid] -= 1
                counts[new_cid] = counts.get(new_cid, 0) + 1

        return self._repair_deck(deck)

    def _is_protected(self, cid: int, counts: Counter) -> bool:
        """Protect hardcore cards (ACE SPECs, Core Special Energies, Search Baseline, Evolution Lines)."""
        if self._csv_idx:
            c = self._csv_idx.get_card(cid)
            if c and c.is_ace_spec:
                return True
            if cid in (15, 16, 18, 19, 20):
                return True
            if cid == 1079:
                return True
            if c and c.is_pokemon and (c.is_stage1 or c.is_stage2 or c.is_mega_ex):
                return True
        if cid == 1119 and counts.get(1119, 0) <= 2:
            return True
        return False

    def _find_replacement(self, old_cid: int, deck: List[int], counts: Counter) -> Optional[int]:
        if not self._csv_idx:
            return None
        old_card = self._csv_idx.get_card(old_cid)
        if not old_card:
            return None

        # Basic Energy Replacement -> Must match deck's energy types
        if old_cid in (1, 2, 3, 4, 5, 6, 7, 8, 9):
            energy_name_to_id = {
                'Grass': 1, 'Fire': 2, 'Water': 3, 'Lightning': 4,
                'Psychic': 5, 'Fighting': 6, 'Darkness': 7, 'Metal': 8, 'Dragon': 9
            }
            cand = [energy_name_to_id[t] for t in self.energy_types if t in energy_name_to_id]
            if 'Psychic' in self.energy_types and counts.get(19, 0) < 4:
                cand.append(19)
            if 'Grass' in self.energy_types and counts.get(18, 0) < 4:
                cand.append(18)
            if 'Fighting' in self.energy_types and counts.get(20, 0) < 4:
                cand.append(20)
            return self.rng.choice(cand) if cand else old_cid

        # Pokemon Replacement -> Must match energy types (or Colorless)
        if old_card.is_pokemon:
            candidates = []
            for cid, card in self._csv_idx.cards.items():
                if cid == old_cid or counts.get(cid, 0) >= 4 or not card.is_pokemon:
                    continue
                card_type = card.type or 'Colorless'
                if card_type not in self.energy_types and card_type != 'Colorless':
                    continue
                # Archetype alignment: Exclude Team Rocket Pokemon if not a TR deck
                if card.is_team_rocket_pokemon and self.archetype != "team_rocket":
                    continue
                if old_card.is_basic and not card.is_basic:
                    continue
                if old_card.is_stage1 and not (card.is_stage1 or card.is_basic):
                    continue
                if old_card.is_stage2 and not (card.is_stage2 or card.is_stage1 or card.is_basic):
                    continue
                candidates.append(cid)
            return self.rng.choice(candidates) if candidates else old_cid

        # Trainer / Item / Supporter Replacement
        candidates = []
        for cid, card in self._csv_idx.cards.items():
            if cid == old_cid or counts.get(cid, 0) >= 4:
                continue
            if not card.is_trainer and not card.is_supporter and not card.is_item:
                continue
            if card.is_ace_spec and any(self._csv_idx.get_card(x) and self._csv_idx.get_card(x).is_ace_spec for x in deck):
                continue
            candidates.append(cid)

        return self.rng.choice(candidates) if candidates else old_cid

    def _repair_deck(self, deck: List[int]) -> List[int]:
        """Strict Chromosome Legality Repair Pipeline.

        Guarantees:
        1. Length == 60 exactly
        2. Max 4 copies of ANY non-basic energy card
        3. Max 1 ACE SPEC
        4. Max 6 Pokemon species
        5. At least 1 Basic Pokemon
        6. Conditional & Archetype invariant preservation (e.g. TR roster requirement)
        7. Basic energy has no copy limit, pad with deck's primary basic energy
        """
        deck = list(deck)
        primary_energy_id = self._get_primary_energy_id()

        # 1. Cap counts at 4 (or 1 for ACE SPEC) - Basic energies (IDs 1-9) have NO cap in PTCG rules
        counts = Counter()
        ace_spec_found = False
        repaired = []

        for cid in deck:
            c_data = self._csv_idx.get_card(cid) if self._csv_idx else None
            is_basic_energy = cid in (1, 2, 3, 4, 5, 6, 7, 8, 9)
            is_ace = bool(c_data and c_data.is_ace_spec)
            max_allowed = 60 if is_basic_energy else (1 if is_ace else 4)

            if is_ace:
                if ace_spec_found:
                    continue
                ace_spec_found = True

            if counts[cid] < max_allowed:
                repaired.append(cid)
                counts[cid] += 1

        deck = repaired

        # 2. Check Team Rocket Invariant: Card 431 requires 4+ TR Pokemon
        if self._csv_idx:
            tr_count = sum(1 for cid in deck if self._csv_idx.get_card(cid) and self._csv_idx.get_card(cid).is_team_rocket_pokemon)
            if tr_count < 4 or self.archetype != "team_rocket":
                valid_replacements = [
                    cid for cid, c in self._csv_idx.cards.items()
                    if c.is_pokemon and c.is_basic and not c.is_team_rocket_pokemon and (c.type in self.energy_types or c.type == 'Colorless')
                ]
                new_deck = []
                for cid in deck:
                    c = self._csv_idx.get_card(cid)
                    if c and c.is_team_rocket_pokemon and self.archetype != "team_rocket":
                        rep = self.rng.choice(valid_replacements) if valid_replacements else primary_energy_id
                        new_deck.append(rep)
                    else:
                        new_deck.append(cid)
                deck = new_deck

        # 3. Ensure at least 1 Basic Pokemon exists
        has_basic = False
        if self._csv_idx:
            for cid in deck:
                c = self._csv_idx.get_card(cid)
                if c and c.is_pokemon and c.is_basic:
                    has_basic = True
                    break

            if not has_basic:
                basic_candidates = [
                    cid for cid, c in self._csv_idx.cards.items()
                    if c.is_pokemon and c.is_basic and not c.is_team_rocket_pokemon and (c.type in self.energy_types or c.type == 'Colorless')
                ]
                if basic_candidates:
                    deck.append(self.rng.choice(basic_candidates))

            # 3b. Evolutionary Legality: Purge Rare Candy (1079) if NO Stage 2 Pokemon in deck
            has_stage2_pkmn = any(
                self._csv_idx.get_card(cid) and (self._csv_idx.get_card(cid).is_stage2 or getattr(self._csv_idx.get_card(cid), 'stage2', False))
                for cid in deck
            )
            if not has_stage2_pkmn and 1079 in deck:
                deck = [cid for cid in deck if cid != 1079]

            # 3c. Prune orphaned evolution cards whose base form is not in the deck
            deck_names = {self._csv_idx.get_card(cid).name.lower() for cid in deck if self._csv_idx.get_card(cid) and self._csv_idx.get_card(cid).is_pokemon}
            cleaned_deck = []
            for cid in deck:
                c = self._csv_idx.get_card(cid)
                if c and c.is_pokemon and (c.is_stage1 or c.is_stage2):
                    # Check if any Pokemon in deck shares the root species prefix
                    root_name = c.name.split()[0].lower()
                    if not any(root_name in existing_name for existing_name in deck_names if existing_name != c.name.lower()):
                        # Orphaned evolution card without base! Replace with basic energy or basic Pokemon
                        cleaned_deck.append(primary_energy_id)
                        continue
                cleaned_deck.append(cid)
            deck = cleaned_deck

        # 4. Enforce exactly 60 cards using Primary Basic Energy for padding
        while len(deck) < 60:
            deck.append(primary_energy_id)
        if len(deck) > 60:
            deck = deck[:60]

        return deck

    def get_best_deck(self) -> Optional[List[int]]:
        if self.best_ever:
            return list(self.best_ever.deck)
        if self.population:
            return list(max(self.population, key=lambda x: x.fitness).deck)
        return None

    def get_stats(self) -> Dict[str, Any]:
        if not self.population:
            return {}
        fitnesses = [ind.fitness for ind in self.population]
        return {
            'generation': self.generation,
            'population_size': len(self.population),
            'best_fitness': round(max(fitnesses), 4),
            'avg_fitness': round(sum(fitnesses) / max(1, len(fitnesses)), 4),
            'best_ever_fitness': round(self.best_ever.fitness if self.best_ever else 0.0, 4),
        }


class MapElitesIslandOptimizer:
    """
    Multi-Island Co-Evolutionary Genetic Algorithm with MAP-Elites Diversity Niching.
    
    Partitions populations into tactical islands (Aggro, Balanced, Stall, Prize Rush)
    with periodic migration and cross-island elite breeding.
    """

    ISLAND_ARCHETYPES = ['aggro', 'balanced', 'stall', 'prize_rush']

    def __init__(
        self,
        base_deck: List[int],
        island_count: int = 4,
        population_per_island: int = 8,
        migration_interval: int = 2,
        seed: int = 42,
        csv_index: Optional[CsvDataIndex] = None,
        energy_types: Optional[List[str]] = None
    ):
        self.base_deck = list(base_deck)
        self.migration_interval = migration_interval
        self.islands: Dict[str, GeneticOptimizer] = {}
        self.generation = 0
        self.best_overall: Optional[Individual] = None

        for i, arch in enumerate(self.ISLAND_ARCHETYPES[:island_count]):
            self.islands[arch] = GeneticOptimizer(
                base_deck=self.base_deck,
                population_size=population_per_island,
                seed=seed + i * 100,
                csv_index=csv_index,
                energy_types=energy_types,
                archetype=arch
            )

    def evolve_generation(self, fitness_fn: Optional[callable] = None) -> Dict[str, Any]:
        """Evolves all islands independently and executes migration when due."""
        self.generation += 1
        island_stats = {}

        for arch, optimizer in self.islands.items():
            best_ind = optimizer.step(fitness_fn=fitness_fn)
            island_stats[arch] = optimizer.get_stats()
            if self.best_overall is None or (best_ind and best_ind.fitness > self.best_overall.fitness):
                self.best_overall = best_ind.copy()

        # Island Migration
        if self.generation % self.migration_interval == 0 and len(self.islands) > 1:
            island_keys = list(self.islands.keys())
            for i, src_key in enumerate(island_keys):
                dst_key = island_keys[(i + 1) % len(island_keys)]
                src_opt = self.islands[src_key]
                dst_opt = self.islands[dst_key]
                if src_opt.population and dst_opt.population:
                    src_elite = max(src_opt.population, key=lambda x: x.fitness).copy()
                    # Replace worst in destination with migrated elite
                    worst_idx = min(range(len(dst_opt.population)), key=lambda idx: dst_opt.population[idx].fitness)
                    dst_opt.population[worst_idx] = src_elite

        return {
            'generation': self.generation,
            'islands': island_stats,
            'best_overall_fitness': round(self.best_overall.fitness if self.best_overall else 0.0, 4)
        }

    def get_best_deck(self) -> Optional[List[int]]:
        if self.best_overall:
            return list(self.best_overall.deck)
        best_candidates = [opt.get_best_deck() for opt in self.islands.values() if opt.get_best_deck()]
        return best_candidates[0] if best_candidates else self.base_deck
